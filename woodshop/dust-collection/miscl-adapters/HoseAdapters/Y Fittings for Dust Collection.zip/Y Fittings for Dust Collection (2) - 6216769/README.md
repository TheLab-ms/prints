Y Fittings for Dust Collection (2) by DPs_Designs on Thingiverse: https://www.thingiverse.com/thing:6216769

Summary:
Dust Collection Y Fittings:Feel to ask for custom sizes or modifications
 and I'll see what I can do for you.

2.5_to_1.5_Y.stl - This just a simple 2.5" Y connection with a curved 1.5" intersection.
	Note: one end of the 2.5" pipe and the end of the 1.5" are tapered on the
	inside for better air flow.
	2.5" Pipe: OD = 2.5"  ID = 2.3125"
	1.5" Pipe: OD = 1.43"  ID = 1.2425"

"2.5_to_1.5_Y_with_2.5_Coupler.stl" - Same as the one above, but with a coupler on 
	one end to slip over another 2.5" pipe.
	2.5" Pipe: OD = 2.5"
	ID = 2.3125"2.5"
	Coupler: OD = 2.507"
	 ID = 2.6945"1.5"
	 Pipe: OD = 1.43"  ID = 1.2425" 
