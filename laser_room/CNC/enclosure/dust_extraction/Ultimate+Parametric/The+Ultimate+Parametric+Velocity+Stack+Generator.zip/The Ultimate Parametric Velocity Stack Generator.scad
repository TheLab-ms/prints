/* ======================================================================
   PROJECT: Ultimate Parametric Velocity Stack Generator
   PLATFORM: MakerWorld Exclusive Model
   AUTHOR:  [Vasilis Charalampopoulos]
   PROFILE: [https://makerworld.com/en/@BasilisCharala]
   DATE:    Released 2025-12-05
   ======================================================================

   LICENSE & EXCLUSIVITY:
   This model is published exclusively on MakerWorld. 
   
   1. NO RE-DISTRIBUTION: Re-uploading this source code (.scad) or generated files (.stl) to other 3D model repositories is STRICTLY PROHIBITED.
   
   2. NON-COMMERCIAL: This work is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0).

   3. ATTRIBUTION: If you share photos or videos of your build, please credit the author.

   DISCLAIMER:
   This is a DIY automotive component. Use at your own risk. 
   The author is not responsible for engine damage caused by improper installation or material failure.
   ======================================================================
*------------------------------------------------
   Features: 
   - Infinite Intake & Bell Sizing
   - Advanced Surface Textures (Golf Ball / Vortex)
   - Integrated Honeycomb Protection Screen
   - Universal Bolt Pattern Generator
   - NEW: Zip Tie / Hose Clamp Retention Ridge (Flange Type 4)
*/

/* [General Dimensions] */
// Inner Diameter of the throat (mm)
throat_diameter = 40; 
// Outer Diameter of the bellmouth top (mm)
bell_diameter = 75; 
// Total height of the stack (mm)
total_height = 80; 
// Thickness of the walls (mm)
wall_thickness = 3; 

/* [Pro Features: Protection Mesh] */
// Enable built-in honeycomb screen?
enable_mesh = false; 
mesh_thickness = 1.0; 
mesh_cell_size = 6.0;
mesh_depth = 5.0;

/* [Bell Geometry & Aerodynamics] */
// 1.0 = Circular, >1.0 = Elliptical, <1.0 = Flat
flare_shape_factor = 1.0; 
enable_lip_rounding = true; 
base_fillet_radius = 0; 

/* [Mounting & Flange Settings] */
// 0:None, 1:Square, 2:Oval, 3:Circular, 4:Zip Tie/Hose Ridge
flange_type = 2; // [0:None, 1:Square, 2:Oval/Diamond, 3:Circular / N-Bolt, 4:Zip Tie / Hose Ridge]

// -- Bolt Settings (For Types 1,2,3) --
circular_bolt_count = 4; 
bolt_spacing = 65; 
bolt_hole_size = 6.5; 
flange_thickness = 5; 
flange_corner_radius = 5;
bolt_rotation = 0;

// -- Zip Tie Settings (For Type 4) --
// How wide is the retention ridge?
ridge_width = 3.0; 
// How much does it stick out?
ridge_height = 1.5; 
// How far from the bottom?
ridge_offset = 5.0;

/* [Aerodynamic Finish] */
surface_finish = 0; // [0:Smooth, 1:Golf Ball, 2:Vortex]
texture_depth = 1.2; 
twist_angle = 90; 
dimple_density = 12; 

/* [Resolution] */
$fn = 60; 

// --- MAIN RENDER ---

difference() {
    union() {
        stack_body();
        
        // Generate Flange OR Zip Tie Ridge
        if (flange_type > 0 && flange_type < 4) {
            generate_flange();
        } else if (flange_type == 4) {
            generate_zip_tie_ridge();
        }
        
        if (enable_mesh) {
            generate_honeycomb();
        }
    }
    
    // Surface Finish Subtraction
    translate([0,0,0.1]) {
        if (surface_finish == 1) {
            generate_dimples();
        } else if (surface_finish == 2) {
            generate_vortex();
        }
    }
}

// --- MODULES ---

module stack_body() {
    flare_radius = (bell_diameter - throat_diameter) / 2;
    straight_height = total_height - flare_radius;
    epsilon = 0.1;

    rotate_extrude(convexity = 10) {
        union() {
            // A. Vertical throat
            translate([throat_diameter/2, 0, 0])
                square([wall_thickness, straight_height + epsilon]);
            
            // B. Base Fillet (Only for bolted flanges)
            if (flange_type > 0 && flange_type < 4 && base_fillet_radius > 0) {
                translate([throat_diameter/2 + wall_thickness, flange_thickness])
                difference() {
                    square(base_fillet_radius);
                    translate([base_fillet_radius, base_fillet_radius])
                        circle(r = base_fillet_radius);
                }
            }

            // C. Flared Bellmouth
            translate([throat_diameter/2 + flare_radius, straight_height, 0])
                union() {
                    difference() {
                        scale([1, flare_shape_factor]) 
                            circle(r = flare_radius); 
                        
                        scale([1, flare_shape_factor]) {
                            if (flare_radius > wall_thickness) {
                                circle(r = flare_radius - wall_thickness);
                            } else {
                                circle(r = 0.1);
                            }
                        }
                        
                        translate([-flare_radius*2, -flare_radius*2 * flare_shape_factor]) 
                            square([flare_radius*4, flare_radius*2 * flare_shape_factor]);
                        translate([0, -flare_radius*2 * flare_shape_factor]) 
                            square([flare_radius*2, flare_radius*4 * flare_shape_factor]);
                    }

                    if (enable_lip_rounding) {
                         lip_cy = (flare_radius - (wall_thickness / 2)) * flare_shape_factor;
                         translate([0, lip_cy])
                            scale([1, flare_shape_factor])
                            circle(d = wall_thickness);
                    }
                }
        }
    }
}

module generate_flange() {
    linear_extrude(flange_thickness) {
        difference() {
            rotate([0, 0, bolt_rotation]) {
                if (flange_type == 1) { // Square
                    offset(r=flange_corner_radius) 
                        square([bolt_spacing + 20, bolt_spacing + 20], center=true);
                } 
                else if (flange_type == 2) { // Oval / Diamond
                    hull() {
                        translate([bolt_spacing/2, 0, 0]) circle(d=bolt_hole_size * 3);
                        translate([-bolt_spacing/2, 0, 0]) circle(d=bolt_hole_size * 3);
                        circle(d=throat_diameter + wall_thickness*2);
                    }
                }
                else if (flange_type == 3) { // Circular
                    circle(d = bolt_spacing + 25);
                }
            }
            circle(d = throat_diameter);
             rotate([0, 0, bolt_rotation]) {
                if (flange_type == 1) { 
                     translate([bolt_spacing/2, bolt_spacing/2]) circle(d=bolt_hole_size);
                     translate([-bolt_spacing/2, bolt_spacing/2]) circle(d=bolt_hole_size);
                     translate([bolt_spacing/2, -bolt_spacing/2]) circle(d=bolt_hole_size);
                     translate([-bolt_spacing/2, -bolt_spacing/2]) circle(d=bolt_hole_size);
                }
                else if (flange_type == 2) { 
                    translate([bolt_spacing/2, 0]) circle(d=bolt_hole_size);
                    translate([-bolt_spacing/2, 0]) circle(d=bolt_hole_size);
                }
                else if (flange_type == 3) { 
                    for (i = [0 : circular_bolt_count-1]) {
                        rotate([0, 0, i * (360 / circular_bolt_count)])
                        translate([bolt_spacing/2, 0])
                        circle(d = bolt_hole_size);
                    }
                }
            }
        }
    }
}

module generate_zip_tie_ridge() {
    // Creates a raised ring around the base for hose clamps/zip ties
    translate([0, 0, ridge_offset])
    rotate_extrude() {
        translate([throat_diameter/2 + wall_thickness, 0, 0])
        difference() {
            // The Ridge Shape (Trapezoidal for easy printing)
            polygon([
                [0, 0],
                [ridge_height, 0],
                [ridge_height, ridge_width],
                [0, ridge_width]
            ]);
            // Optional: Chamfer the top edge for smoother hose insertion
            translate([ridge_height, ridge_width])
            rotate(45)
            square(ridge_height);
        }
    }
}

module generate_honeycomb() {
    hex_radius = mesh_cell_size / sqrt(3); 
    col_spacing = mesh_cell_size + mesh_thickness;
    row_spacing = col_spacing * 0.866025; 
    
    intersection() {
        cylinder(d = throat_diameter + 1.2, h = mesh_depth);
        difference() {
            cylinder(d = throat_diameter + 5, h = mesh_depth);
            union() {
                for (x = [-throat_diameter/2 - 5 : col_spacing : throat_diameter/2 + 5]) {
                    for (y = [-throat_diameter/2 - 5 : row_spacing : throat_diameter/2 + 5]) {
                        translate([x + (round(y/row_spacing)%2 * col_spacing/2), y, -0.1])
                            cylinder(d = mesh_cell_size, h = mesh_depth + 0.2, $fn=6);
                    }
                }
            }
        }
    }
}

module generate_dimples() {
    flare_radius = (bell_diameter - throat_diameter) / 2;
    straight_height = total_height - flare_radius;
    for (z = [5 : 8 : straight_height]) {
        count = floor((throat_diameter * 3.14) / 8); 
        for (a = [0 : 360/count : 360]) {
             translate([0, 0, z])
                rotate([0, 0, a + (z%2)*15]) 
                translate([throat_diameter/2, 0, 0])
                sphere(d = texture_depth * 4, $fn=12); 
        }
    }
    for (angle = [0 : 15 : 75]) { 
        z_pos = straight_height + ((flare_radius * sin(angle)) * flare_shape_factor);
        r_pos = (throat_diameter/2 + flare_radius) - (flare_radius * cos(angle));
        circumference = 2 * 3.14159 * r_pos;
        count_curve = floor(circumference / 8);
        for (rot = [0 : 360/count_curve : 360]) {
             translate([0,0, straight_height]) 
             rotate([0, 0, rot])
             translate([throat_diameter/2 + flare_radius, 0, 0]) 
             rotate([0, (-angle * flare_shape_factor) - 90, 0]) 
             translate([flare_radius, 0, 0]) 
             sphere(d = texture_depth * 4, $fn=12);
        }
    }
}

module generate_vortex() {
    cuts = 8;
    intersection() {
        cylinder(r=bell_diameter, h=total_height);
        for (i = [0:cuts-1]) {
            rotate([0, 0, i * (360/cuts)])
            linear_extrude(height = total_height, twist = twist_angle, slices = 100)
            translate([throat_diameter/2 - texture_depth/2, 0, 0])
            circle(r = texture_depth, $fn=20);
        }
    }
}